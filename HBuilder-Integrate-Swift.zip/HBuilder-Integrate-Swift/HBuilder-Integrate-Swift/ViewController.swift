//
//  ViewController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 16/7/19.
//  Copyright © 2016年 EICAPITAN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var ButWebView : UIButton?
    @IBOutlet var ButWidget : UIButton?
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func ButtonAction(_ sender:UIButton!){
        let tag = sender.tag;
        switch tag {
        case 101:
            self.navigationController?.pushViewController(WebViewController(), animated: true);
            break;
        case 102:
            self.navigationController?.isNavigationBarHidden = true;
            self.navigationController?.pushViewController(WebAppController(), animated: true);
            break;
        default:
            break;
        }
    }
}

