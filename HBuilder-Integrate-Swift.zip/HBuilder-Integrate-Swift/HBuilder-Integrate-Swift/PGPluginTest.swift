//
//  Plugintest.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 16/7/20.
//  Copyright © 2016年 EICAPITAN. All rights reserved.
//

import Foundation

@objc(PGPluginTest)

class PGPluginTest:PGPlugin
{
    var glcbid : String? = nil;
    var Result : PDRPluginResult? = nil
    var webObj : H5WEWebEngine? = nil
    var arguArray : Array<AnyObject>?

    func onAppStarted(_ options : NSDictionary) {
        
    }
    
    // 监听基座事件事件
    // 应用退出时触发
    func onAppTerminate(){
        //
        NSLog("APPDelegate applicationWillTerminate 事件触发时触发");
    }
    
    // 应用进入后台时触发
    func onAppEnterBackground(){
        //
        NSLog("APPDelegate applicationDidEnterBackground 事件触发时触发");
    }
    
    // 应用进入前时触发
    func onAppEnterForeground(){
        //
        NSLog("APPDelegate applicationWillEnterForeground 事件触发时触发");
    }
    
    // 以下为插件方法，由JS触发， WebView集成和WebApp集成都可以触发
    
    func PluginTestFunction(_ commands:PGMethod?)
    {
        if commands == nil {
            return;
        }
        // CallBackid 异步方法的回调id，H5+ 会根据回调ID通知JS层运行结果成功或者失败
        let cbid : String = (commands?.arguments?[0])! as! String;
        // 用户的参数会在第二个参数传回,传入的顺序和JS层参数传递的顺序一致
        let pArgument1 : String = (commands?.arguments?[1])! as! String;
        let pArgument2 : String = (commands?.arguments?[2])! as! String;
        let pArgument3 : String = (commands?.arguments?[3])! as! String;
        let pArgument4 : String = (commands?.arguments?[4])! as! String;
        // 如果使用Array方式传递参数
        let pResultString : NSArray = [pArgument1, pArgument2, pArgument3, pArgument4];
        
        // 运行Native代码结果和预期相同，调用回调通知JS层运行成功并返回结果
        // PDRCommandStatusOK 表示触发JS层成功回调方法
        // PDRCommandStatusError 表示触发JS层错误回调方法
        
        // 如果方法需要持续触发页面回调，可以通过修改 PDRPluginResult 对象的keepCallback 属性值来表示当前是否可重复回调， true 表示可以重复回调   false 表示不可重复回调  默认值为false
        
        let result:PDRPluginResult? = PDRPluginResult.init(status: PDRCommandStatusOK, messageAs: pResultString as [AnyObject]);
        
        // 如果Native代码运行结果和预期不同，需要通过回调通知JS层出现错误，并返回错误提示
        //PDRPluginResult *result = [PDRPluginResult resultWithStatus:PDRCommandStatusError messageAsString:@"惨了! 出错了！ 咋(wu)整(liao)"];
        
        // 通知JS层Native层运行结果
        self.toCallback(cbid, withReslut: result?.toJSONString());
    }
    
    // 异步方法，异步回调将数据返回给页面
    func PluginTestFunctionArrayArgu(_ commands: PGMethod?)
    {
        if commands == nil {
            return;
        }
        glcbid = (commands?.arguments?[0])! as? String;
        arguArray = (commands?.arguments?[1])! as? Array<AnyObject> ;
        webObj = self.jsFrameContext.webEngine;
        self.perform(#selector(asyncToWebView), with: nil, afterDelay: 2)
    }
    
    // 异步将数据返回给
    func asyncToWebView() {
        
        Result = PDRPluginResult.init(status: PDRCommandStatusOK, messageAs: arguArray);
        self.toCallback(glcbid, withReslut: Result?.toJSONString());
       // webObj?.evaluateJavaScript("alert('11111')", completionHandler: nil);
    }
    
    
    
}
