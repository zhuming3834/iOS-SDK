//
//  WebViewController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 16/7/19.
//  Copyright © 2016年 EICAPITAN. All rights reserved.
//

import Foundation
import UIKit

class WebViewController: UIViewController
{
    var  appFrame : PDRCoreAppFrame?
    var  coreHandle : PDRCore?
    override func viewDidLoad() {
        super.viewDidLoad()
        coreHandle = PDRCore.instance();
        let FilePath : String = "file://" + Bundle.main.bundlePath + "/Pandora/apps/HelloH5/www/plugin.html";
        
        if PDRCore.instance().responds(to: Selector("startAsWebClient")) {
            PDRCore.instance().perform(Selector("startAsWebClient"))
        }
        
        let stRect : CGRect? = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height);
        appFrame = PDRCoreAppFrame.init(name: "WebViewID1", loadURL: FilePath, frame: stRect!);
        coreHandle?.appManager.activeApp.appWindow.registerFrame(appFrame);
        self.view.addSubview(appFrame!);
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
