//
//  WebAppController.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 16/7/19.
//  Copyright © 2016年 EICAPITAN. All rights reserved.
//

import Foundation
import UIKit



class WebAppController: UIViewController,PDRCoreDelegate
{
    var h5Engine : PDRCore? = PDRCore.instance()
    var _statusBarStyle :UIStatusBarStyle? = UIStatusBarStyle.default
    var _isFullScreen = false
    var _containerView: UIView? = nil
    var _statusBarView : UIView? = nil
    var defalutStausBarColor : UIColor? = UIColor.white
    var kStatusBarHeight:CGFloat = 20
    var pAppHandle : PDRCoreApp?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        _statusBarStyle = h5Engine?.settings.statusBarStyle;
        _isFullScreen = UIApplication.shared.isStatusBarHidden;
        if _isFullScreen != h5Engine?.settings.fullScreen {
           _isFullScreen = (h5Engine?.settings.fullScreen)!
            if self.responds(to: #selector(UIViewController.setNeedsStatusBarAppearanceUpdate)) {
                self.setNeedsStatusBarAppearanceUpdate();
            }else{
                UIApplication.shared.setStatusBarHidden(_isFullScreen, with: UIStatusBarAnimation.none)
            }
        }
        
        var newRect = self.view.bounds;
        if self.reserveStatusbarOffset() && PTDeviceOSInfo.systemVersion().rawValue > PTSystemVersion.version6Series.rawValue {
            if !_isFullScreen {
                newRect.origin.y += kStatusBarHeight;
                newRect.size.height -= kStatusBarHeight;
            }
            _statusBarView = UIView.init(frame: CGRect(x: 0, y: 0, width: newRect.size.width, height: kStatusBarHeight))
            _statusBarView?.backgroundColor = h5Engine?.settings.statusBarColor
            _statusBarView?.autoresizingMask = UIViewAutoresizing.flexibleWidth;
            self.view.addSubview(_statusBarView!);
        }
        
        _containerView = UIView.init(frame: newRect);
        
        // 设置5+内核的delegate，
        h5Engine?.coreDeleagete = self;
        h5Engine?.persentViewController = self;
        self.view.addSubview(_containerView!);
        
        
        if ((h5Engine?.responds(to: Selector("startAsAppClient"))) != nil) {
            h5Engine?.perform(Selector("startAsAppClient"));
        }
        
        h5Engine?.setContainerView(_containerView);
        let pArgus = "id=plus.runtime.argument"
        let pWWWPath = Bundle.main.bundlePath + "/Pandora/apps/HelloH5/www";
        pAppHandle = h5Engine?.appManager.openApp(atLocation: pWWWPath, withIndexPath: "index.html", withArgs: pArgus, with: nil)
    }


    
    
    /*
     * @Summary 获取当前状态栏的背景颜色
     */
    func getStatusBarBackground() -> UIColor {
        return (_statusBarView?.backgroundColor)!;
    }
    
    /*
     * @Summary 
     */
    override var shouldAutorotate : Bool {
        return true;
    }
    
    /*
     * @Summary 获取当前是否全屏显示
     */
    override var prefersStatusBarHidden : Bool {
        return _isFullScreen;
    }
    
    /*
     * @Summary 状态栏隐藏动画
     */
    override var preferredStatusBarUpdateAnimation : UIStatusBarAnimation {
        return UIStatusBarAnimation.fade;
    }
    
    /*
     * @Summary 当前应用支持旋转的方向
     */
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask(rawValue: (h5Engine?.settings.supportedInterfaceOrientations())!)
    }
    
    /*
     * @Summary
     */
    func getStatusBarStyle() -> UIStatusBarStyle {
        return self.preferredStatusBarStyle;
    }
    
    /*
     * @Summary
     */
    override var preferredStatusBarStyle : UIStatusBarStyle{
        return self._statusBarStyle!;
    }
    
    /*
     * @Summary
     */
    func reserveStatusbarOffset() -> Bool {
        return PDRCore.instance()!.settings!.reserveStatusbarOffset;
    }
    
    /*
     * @Summary
     */
    func setStatusBarBackground(_ newColor:UIColor!)  {
            _statusBarView!.backgroundColor = newColor!;
    }
    
    
    /*
     * @Summary
     */
    func getStatusBarHidden() -> Bool {
        
        if PTDeviceOSInfo.systemVersion().rawValue > PTSystemVersion.version6Series.rawValue {
            return _isFullScreen;
        }
        
        return UIApplication.shared.isStatusBarHidden;
    }
    
    
    /*
     * @Summary
     */
    func setStatusBarStyle(_ statusBarStyle: UIStatusBarStyle) {
        if _statusBarStyle!.rawValue != statusBarStyle.rawValue {
            _statusBarStyle = statusBarStyle;
            if self.responds(to: #selector(UIViewController.setNeedsStatusBarAppearanceUpdate))
            {
                self.setNeedsStatusBarAppearanceUpdate();
            }else{
                UIApplication.shared.setStatusBarStyle(_statusBarStyle!, animated: false);
            }
        }
    }
    
    
    /*
     * @Summary
     */
    override func willAnimateRotation(to toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        h5Engine?.handle(PDRCoreSysEvent.interfaceOrientation, with: NSNumber.init(value: toInterfaceOrientation.rawValue as Int) )
        if PTDeviceOSInfo.systemVersion().rawValue >= PTSystemVersion.version8Series.rawValue  {
            UIApplication.shared.setStatusBarHidden(_isFullScreen, with: UIStatusBarAnimation.none);
        }
    }
    
    /*
     * @Summary
     */
    func wantsFullScreen(_ fullScreen: Bool) {
        if !_isFullScreen {
            return;
        }
        
        _isFullScreen = fullScreen;
        UIApplication.shared.setStatusBarHidden(_isFullScreen, with: _isFullScreen ? UIStatusBarAnimation.fade : UIStatusBarAnimation.none);
        
        if PTDeviceOSInfo.systemVersion().rawValue > PTSystemVersion.version6Series.rawValue
        {
            self.setNeedsStatusBarAppearanceUpdate();
        }
        
        var newRect:CGRect? = self.view.bounds;
        
        if PTDeviceOSInfo.systemVersion().rawValue <= PTSystemVersion.version6Series.rawValue
        {
            newRect = UIApplication.shared.keyWindow?.bounds;
            if _isFullScreen {
                UIView.beginAnimations(nil, context: nil);
                self.view.frame = newRect!;
                UIView.commitAnimations();
            }else{
                
                let interfaceOrientation:UIInterfaceOrientation? = UIApplication.shared.statusBarOrientation;
                if UIDeviceOrientation.landscapeLeft.rawValue == interfaceOrientation?.rawValue ||
                    interfaceOrientation?.rawValue == UIDeviceOrientation.landscapeRight.rawValue
                {
                    newRect?.size.width -= kStatusBarHeight;
                }else{
                    newRect?.origin.y += kStatusBarHeight;
                    newRect?.size.height -= kStatusBarHeight;
                }
                
                UIView.beginAnimations(nil, context: nil);
                self.view.frame = newRect!;
                UIView.commitAnimations();
            }
        }else{
            if reserveStatusbarOffset() {
                _statusBarView?.isHidden = _isFullScreen;
                if _isFullScreen {
                    newRect?.origin.y += kStatusBarHeight;
                    newRect?.size.height -= kStatusBarHeight;
                }
            }
            _containerView?.frame = newRect!;
        }
        PDRCore.instance().handle(PDRCoreSysEvent.interfaceOrientation, with: NSNumber.init(value: 0 as Int32) );
    }
    
    
    /*
     * @Summary
     */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
