//
//  AppDelegate.swift
//  HBuilder-Integrate-Swift
//
//  Created by EICAPITAN on 16/7/19.
//  Copyright © 2016年 EICAPITAN. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        let NavController : UINavigationController? = UINavigationController.init(rootViewController: (window?.rootViewController)!);
        window?.rootViewController = NavController
        
        PDRCore.initEngineWihtOptions(launchOptions, with: PDRCoreRunMode.appClient);
        return true
    }
    
    // 如果此段代码报错，请升级xcode到最新或者删除此代码
    /*
     * @Summary: 应用压力菜单相应方法
     *
     */
    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        PDRCore.handle(PDRCoreSysEvent.peekQuickAction, with: shortcutItem);
        completionHandler(true);
    }

    /*
     * @Summary:应用进入前台
     *
     */
    func applicationDidEnterBackground(_ application: UIApplication) {
        
        PDRCore.instance().handle(PDRCoreSysEvent.enterBackground, with: nil);
     }

    /*
     * @Summary:应用进入后台
     *
     */
    func applicationWillEnterForeground(_ application: UIApplication) {
        PDRCore.instance().handle(PDRCoreSysEvent.enterForeGround, with: nil);
    }


    /*
     * @Summary:应用关闭
     *
     */
    func applicationWillTerminate(_ application: UIApplication) {
        PDRCore.destoryEngine();
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    /*
     * @Summary:程序被第三方调用，传入参数启动
     *
     */
    func application(_ application: UIApplication, handleOpen url: URL) -> Bool {
        PDRCore.instance().handle(PDRCoreSysEvent.openURL, with: url);
        return true;
    }
    
    /*
     * @Summary:远程push注册成功收到DeviceToken回调
     *
     */
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        PDRCore.instance().handle(PDRCoreSysEvent.revDeviceToken, with: deviceToken);
    }
    /*
     * @Summary: 收到远程推动信息
     */
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        PDRCore.instance().handle(PDRCoreSysEvent.revRemoteNotification, with: userInfo);
    }
    
    /*
     * @Summary: 远程push注册失败
     */
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        PDRCore.instance().handle(PDRCoreSysEvent.regRemoteNotificationsError, with: error);
    }
    
    /*
     * @Summary:程序收到本地消息
     */
    func application(_ application: UIApplication, didReceive notification: UILocalNotification) {
        PDRCore.instance().handle(PDRCoreSysEvent.revLocalNotification, with: notification);
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
    }

    
}

